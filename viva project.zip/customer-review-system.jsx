import { useState, useEffect } from "react";

const initialReviews = [
  {
    id: 1,
    name: "Priya Sharma",
    avatar: "PS",
    rating: 5,
    product: "Wireless Headphones",
    date: "2026-03-18",
    title: "Absolutely phenomenal sound!",
    body: "These headphones completely changed how I experience music. The noise cancellation is top-notch and the battery life is incredible. Worth every rupee.",
    helpful: 24,
    category: "Electronics",
    verified: true,
  },
  {
    id: 2,
    name: "Arjun Mehta",
    avatar: "AM",
    rating: 4,
    product: "Running Shoes",
    date: "2026-03-22",
    title: "Great for daily runs",
    body: "Comfortable, lightweight, and durable. My knees thank me every morning. Only wish the color options were wider. Otherwise a solid buy.",
    helpful: 11,
    category: "Footwear",
    verified: true,
  },
  {
    id: 3,
    name: "Lakshmi Nair",
    avatar: "LN",
    rating: 3,
    product: "Coffee Maker",
    date: "2026-03-25",
    title: "Decent, but nothing special",
    body: "Makes good coffee, but the water reservoir is a bit small. Have to refill every two cups. Customer service was responsive when I had questions.",
    helpful: 6,
    category: "Kitchen",
    verified: false,
  },
  {
    id: 4,
    name: "Rohan Das",
    avatar: "RD",
    rating: 2,
    product: "Laptop Stand",
    date: "2026-03-27",
    title: "Wobbles too much",
    body: "Looked great in photos but the build quality is disappointing. Wobbles noticeably and doesn't feel secure. Returned it after a week.",
    helpful: 18,
    category: "Office",
    verified: true,
  },
];

const CATEGORIES = ["All", "Electronics", "Footwear", "Kitchen", "Office"];
const SORT_OPTIONS = ["Newest", "Highest Rated", "Most Helpful"];

function StarRating({ value, onChange, size = 24 }) {
  const [hovered, setHovered] = useState(0);
  return (
    <div style={{ display: "flex", gap: 2 }}>
      {[1, 2, 3, 4, 5].map((star) => (
        <span
          key={star}
          onClick={() => onChange && onChange(star)}
          onMouseEnter={() => onChange && setHovered(star)}
          onMouseLeave={() => onChange && setHovered(0)}
          style={{
            fontSize: size,
            cursor: onChange ? "pointer" : "default",
            color: star <= (hovered || value) ? "#F59E0B" : "#374151",
            transition: "color 0.15s, transform 0.15s",
            transform: hovered === star && onChange ? "scale(1.2)" : "scale(1)",
            display: "inline-block",
            lineHeight: 1,
          }}
        >
          ★
        </span>
      ))}
    </div>
  );
}

function RatingBar({ label, count, total }) {
  const pct = total ? Math.round((count / total) * 100) : 0;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
      <span style={{ color: "#9CA3AF", fontSize: 13, minWidth: 40 }}>{label} ★</span>
      <div style={{ flex: 1, background: "#1F2937", borderRadius: 4, height: 8, overflow: "hidden" }}>
        <div
          style={{
            width: `${pct}%`,
            height: "100%",
            background: "linear-gradient(90deg, #F59E0B, #EF4444)",
            borderRadius: 4,
            transition: "width 0.6s cubic-bezier(.4,0,.2,1)",
          }}
        />
      </div>
      <span style={{ color: "#6B7280", fontSize: 13, minWidth: 24 }}>{count}</span>
    </div>
  );
}

function ReviewCard({ review, onHelpful }) {
  const [liked, setLiked] = useState(false);

  const handleHelpful = () => {
    if (!liked) {
      setLiked(true);
      onHelpful(review.id);
    }
  };

  const dateStr = new Date(review.date).toLocaleDateString("en-IN", {
    day: "numeric", month: "short", year: "numeric",
  });

  return (
    <div
      style={{
        background: "#111827",
        border: "1px solid #1F2937",
        borderRadius: 16,
        padding: "24px 28px",
        position: "relative",
        transition: "border-color 0.2s, transform 0.2s",
        animation: "fadeSlideIn 0.4s ease both",
      }}
      onMouseEnter={e => { e.currentTarget.style.borderColor = "#374151"; e.currentTarget.style.transform = "translateY(-2px)"; }}
      onMouseLeave={e => { e.currentTarget.style.borderColor = "#1F2937"; e.currentTarget.style.transform = "translateY(0)"; }}
    >
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{
            width: 46, height: 46, borderRadius: "50%",
            background: "linear-gradient(135deg, #6366F1, #EC4899)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontFamily: "Georgia, serif", fontWeight: "bold", color: "#fff", fontSize: 16,
            flexShrink: 0,
          }}>
            {review.avatar}
          </div>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ color: "#F9FAFB", fontWeight: 600, fontSize: 15, fontFamily: "'Playfair Display', serif" }}>{review.name}</span>
              {review.verified && (
                <span style={{
                  fontSize: 11, background: "#064E3B", color: "#6EE7B7",
                  borderRadius: 20, padding: "2px 8px", fontFamily: "monospace",
                }}>✓ Verified</span>
              )}
            </div>
            <div style={{ color: "#6B7280", fontSize: 12, marginTop: 2 }}>{review.product} · {dateStr}</div>
          </div>
        </div>
        <span style={{
          fontSize: 11, background: "#1F2937", color: "#9CA3AF",
          borderRadius: 20, padding: "4px 10px",
        }}>{review.category}</span>
      </div>

      {/* Rating + Title */}
      <div style={{ marginBottom: 10, display: "flex", alignItems: "center", gap: 12 }}>
        <StarRating value={review.rating} size={18} />
        <span style={{ color: "#E5E7EB", fontWeight: 600, fontSize: 16, fontFamily: "'Playfair Display', serif" }}>{review.title}</span>
      </div>

      {/* Body */}
      <p style={{ color: "#9CA3AF", fontSize: 14, lineHeight: 1.7, margin: "0 0 20px" }}>{review.body}</p>

      {/* Footer */}
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <span style={{ color: "#6B7280", fontSize: 13 }}>Helpful?</span>
        <button
          onClick={handleHelpful}
          style={{
            background: liked ? "#1D4ED8" : "#1F2937",
            border: "none", borderRadius: 8,
            color: liked ? "#BFDBFE" : "#9CA3AF",
            padding: "5px 14px", fontSize: 13, cursor: liked ? "default" : "pointer",
            display: "flex", alignItems: "center", gap: 6,
            transition: "background 0.2s, color 0.2s",
          }}
        >
          👍 {review.helpful}
        </button>
      </div>
    </div>
  );
}

function ReviewForm({ onSubmit, onCancel }) {
  const [form, setForm] = useState({ name: "", product: "", category: "Electronics", rating: 0, title: "", body: "" });
  const [errors, setErrors] = useState({});

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = "Name is required";
    if (!form.product.trim()) e.product = "Product name is required";
    if (!form.rating) e.rating = "Please select a rating";
    if (!form.title.trim()) e.title = "Title is required";
    if (form.body.trim().length < 20) e.body = "Review must be at least 20 characters";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (validate()) onSubmit(form);
  };

  const field = (label, key, placeholder, multiline) => (
    <div style={{ marginBottom: 18 }}>
      <label style={{ display: "block", color: "#9CA3AF", fontSize: 12, marginBottom: 6, fontFamily: "monospace", letterSpacing: 1 }}>{label.toUpperCase()}</label>
      {multiline ? (
        <textarea
          value={form[key]}
          onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
          placeholder={placeholder}
          rows={4}
          style={inputStyle(errors[key])}
        />
      ) : (
        <input
          value={form[key]}
          onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
          placeholder={placeholder}
          style={inputStyle(errors[key])}
        />
      )}
      {errors[key] && <div style={{ color: "#F87171", fontSize: 12, marginTop: 4 }}>{errors[key]}</div>}
    </div>
  );

  return (
    <div style={{
      background: "#0F172A", border: "1px solid #3730A3",
      borderRadius: 20, padding: "32px 36px", marginBottom: 32,
      animation: "fadeSlideIn 0.3s ease both",
    }}>
      <h3 style={{ color: "#C7D2FE", fontFamily: "'Playfair Display', serif", fontSize: 22, margin: "0 0 24px" }}>Write a Review</h3>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0 24px" }}>
        {field("Your Name", "name", "e.g. Ananya Krishnan")}
        {field("Product Name", "product", "e.g. Smart Watch")}
      </div>
      <div style={{ marginBottom: 18 }}>
        <label style={{ display: "block", color: "#9CA3AF", fontSize: 12, marginBottom: 6, fontFamily: "monospace", letterSpacing: 1 }}>CATEGORY</label>
        <select
          value={form.category}
          onChange={e => setForm(f => ({ ...f, category: e.target.value }))}
          style={{ ...inputStyle(), width: "100%" }}
        >
          {CATEGORIES.filter(c => c !== "All").map(c => <option key={c}>{c}</option>)}
        </select>
      </div>
      <div style={{ marginBottom: 18 }}>
        <label style={{ display: "block", color: "#9CA3AF", fontSize: 12, marginBottom: 8, fontFamily: "monospace", letterSpacing: 1 }}>RATING</label>
        <StarRating value={form.rating} onChange={r => setForm(f => ({ ...f, rating: r }))} size={32} />
        {errors.rating && <div style={{ color: "#F87171", fontSize: 12, marginTop: 4 }}>{errors.rating}</div>}
      </div>
      {field("Review Title", "title", "Sum it up in a sentence")}
      {field("Your Review", "body", "Tell others what you think...", true)}
      <div style={{ display: "flex", gap: 12, justifyContent: "flex-end" }}>
        <button onClick={onCancel} style={btnStyle("#1F2937", "#9CA3AF")}>Cancel</button>
        <button onClick={handleSubmit} style={btnStyle("linear-gradient(135deg, #6366F1, #8B5CF6)", "#fff")}>Submit Review</button>
      </div>
    </div>
  );
}

const inputStyle = (err) => ({
  background: "#1F2937", border: `1px solid ${err ? "#EF4444" : "#374151"}`,
  borderRadius: 10, padding: "10px 14px", color: "#E5E7EB",
  fontSize: 14, width: "100%", boxSizing: "border-box", outline: "none",
  fontFamily: "inherit", resize: "vertical",
});

const btnStyle = (bg, color) => ({
  background: bg, color, border: "none", borderRadius: 10,
  padding: "10px 24px", fontSize: 14, cursor: "pointer",
  fontFamily: "'Playfair Display', serif", fontWeight: 600,
  transition: "opacity 0.2s",
});

export default function App() {
  const [reviews, setReviews] = useState(initialReviews);
  const [category, setCategory] = useState("All");
  const [sort, setSort] = useState("Newest");
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [toast, setToast] = useState(null);

  const showToast = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2800);
  };

  const handleSubmit = (form) => {
    const newReview = {
      id: Date.now(),
      name: form.name,
      avatar: form.name.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase(),
      rating: form.rating,
      product: form.product,
      date: new Date().toISOString().slice(0, 10),
      title: form.title,
      body: form.body,
      helpful: 0,
      category: form.category,
      verified: false,
    };
    setReviews(r => [newReview, ...r]);
    setShowForm(false);
    showToast("Your review has been published!");
  };

  const handleHelpful = (id) => {
    setReviews(r => r.map(rev => rev.id === id ? { ...rev, helpful: rev.helpful + 1 } : rev));
  };

  const filtered = reviews
    .filter(r => category === "All" || r.category === category)
    .filter(r => {
      const q = search.toLowerCase();
      return !q || r.name.toLowerCase().includes(q) || r.product.toLowerCase().includes(q) || r.title.toLowerCase().includes(q);
    })
    .sort((a, b) => {
      if (sort === "Newest") return new Date(b.date) - new Date(a.date);
      if (sort === "Highest Rated") return b.rating - a.rating;
      return b.helpful - a.helpful;
    });

  const avg = reviews.reduce((s, r) => s + r.rating, 0) / reviews.length;
  const ratingCounts = [5, 4, 3, 2, 1].map(s => ({ star: s, count: reviews.filter(r => r.rating === s).length }));

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=DM+Mono:wght@400;500&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: #030712; min-height: 100vh; }
        @keyframes fadeSlideIn {
          from { opacity: 0; transform: translateY(16px); }
          to { opacity: 1; transform: translateY(0); }
        }
        input, select, textarea { color-scheme: dark; }
        input::placeholder, textarea::placeholder { color: #4B5563; }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #111827; }
        ::-webkit-scrollbar-thumb { background: #374151; border-radius: 3px; }
        .chip { transition: background 0.15s, color 0.15s; }
        .chip:hover { opacity: 0.85; }
      `}</style>

      <div style={{ minHeight: "100vh", background: "#030712", fontFamily: "'DM Mono', monospace", padding: "0 0 60px" }}>
        {/* Header */}
        <div style={{
          background: "linear-gradient(180deg, #0F172A 0%, #030712 100%)",
          borderBottom: "1px solid #1F2937",
          padding: "36px 0 28px",
          textAlign: "center",
        }}>
          <div style={{ fontSize: 11, letterSpacing: 4, color: "#6366F1", marginBottom: 10, fontFamily: "monospace" }}>CUSTOMER FEEDBACK SYSTEM</div>
          <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: 40, color: "#F9FAFB", fontWeight: 700, letterSpacing: -1 }}>
            Reviews & Ratings
          </h1>
          <p style={{ color: "#6B7280", marginTop: 10, fontSize: 14 }}>Trusted opinions from real customers</p>
        </div>

        <div style={{ maxWidth: 900, margin: "0 auto", padding: "0 20px" }}>
          {/* Summary Cards */}
          <div style={{ display: "grid", gridTemplateColumns: "220px 1fr", gap: 24, margin: "40px 0 32px" }}>
            <div style={{
              background: "#0F172A", border: "1px solid #1F2937",
              borderRadius: 20, padding: "28px 24px", textAlign: "center",
            }}>
              <div style={{ fontSize: 56, fontFamily: "'Playfair Display', serif", fontWeight: 700, color: "#F9FAFB", lineHeight: 1 }}>{avg.toFixed(1)}</div>
              <StarRating value={Math.round(avg)} size={20} />
              <div style={{ color: "#6B7280", fontSize: 12, marginTop: 8 }}>{reviews.length} reviews</div>
            </div>
            <div style={{ background: "#0F172A", border: "1px solid #1F2937", borderRadius: 20, padding: "24px 28px" }}>
              {ratingCounts.map(({ star, count }) => (
                <RatingBar key={star} label={star} count={count} total={reviews.length} />
              ))}
            </div>
          </div>

          {/* Controls */}
          <div style={{ display: "flex", flexWrap: "wrap", gap: 12, alignItems: "center", marginBottom: 28 }}>
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search reviews..."
              style={{ ...inputStyle(), flex: 1, minWidth: 180 }}
            />
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {CATEGORIES.map(c => (
                <button
                  key={c}
                  className="chip"
                  onClick={() => setCategory(c)}
                  style={{
                    background: category === c ? "#4F46E5" : "#1F2937",
                    color: category === c ? "#fff" : "#9CA3AF",
                    border: "none", borderRadius: 20,
                    padding: "6px 16px", fontSize: 13, cursor: "pointer",
                  }}
                >{c}</button>
              ))}
            </div>
            <select
              value={sort}
              onChange={e => setSort(e.target.value)}
              style={{ ...inputStyle(), width: "auto" }}
            >
              {SORT_OPTIONS.map(o => <option key={o}>{o}</option>)}
            </select>
            <button
              onClick={() => setShowForm(s => !s)}
              style={{
                background: "linear-gradient(135deg, #6366F1, #8B5CF6)",
                color: "#fff", border: "none", borderRadius: 12,
                padding: "10px 22px", fontSize: 14, cursor: "pointer",
                fontFamily: "'Playfair Display', serif", fontWeight: 600,
                whiteSpace: "nowrap",
              }}
            >+ Write Review</button>
          </div>

          {/* Form */}
          {showForm && <ReviewForm onSubmit={handleSubmit} onCancel={() => setShowForm(false)} />}

          {/* Review List */}
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {filtered.length === 0 ? (
              <div style={{ textAlign: "center", color: "#4B5563", padding: "60px 0", fontSize: 16 }}>
                No reviews found matching your filters.
              </div>
            ) : filtered.map(r => (
              <ReviewCard key={r.id} review={r} onHelpful={handleHelpful} />
            ))}
          </div>
        </div>
      </div>

      {/* Toast */}
      {toast && (
        <div style={{
          position: "fixed", bottom: 32, left: "50%", transform: "translateX(-50%)",
          background: "#064E3B", color: "#6EE7B7", borderRadius: 12,
          padding: "14px 28px", fontSize: 14, fontFamily: "monospace",
          boxShadow: "0 8px 32px rgba(0,0,0,0.5)",
          animation: "fadeSlideIn 0.3s ease both",
          zIndex: 100,
        }}>
          ✓ {toast}
        </div>
      )}
    </>
  );
}
